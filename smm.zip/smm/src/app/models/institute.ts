export class Institute{
    InstituteId: number;
    InstituteFullName:string;
    InstituteTypeId: number;
    InstituteTypeName:string;
    AffiliatedId: number;
    AffiliatedName:string;
    OtherAffiliatedName:string;
    MediumOfCommunication:string;
    Address1:string;
    Address2: string;
    StateId: number;
    StateName:string;
    DistrictId: number;
    DistrictName:string;
    CountryName:string;
    PinCode:number;
    MobileNumber:number;
    PhoneNumber:string;
    EmailId:string;

    constructor(){
        this.InstituteId = 0;
        this.InstituteFullName = '';
        this.InstituteTypeId = 0;
        this.InstituteTypeName = '';
        this.AffiliatedId = 0;
        this.AffiliatedName = '';
        this. OtherAffiliatedName = '';
        this.MediumOfCommunication = '';
        this.Address1 = '';
        this.Address2 = '';
        this.StateId = 0;
        this.StateName = '';
        this.DistrictName = '';
        this.DistrictId = 0;
        this.CountryName = '';
        this.PinCode = 0;
        this.MobileNumber = 0;
        this.PhoneNumber = '';
        this.EmailId = '';
    }
}