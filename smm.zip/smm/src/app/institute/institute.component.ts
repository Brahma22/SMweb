import { Component } from "@angular/core";

@Component({
    selector: 'app-institute',
    templateUrl: './institute.component.html',
    styleUrls: ['./institute.component.css']

})
export class InstituteComponent{

}