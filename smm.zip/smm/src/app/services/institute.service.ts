import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { Institute } from "../models/institute";

@Injectable({
    providedIn: 'root'  
})
export class InstituteService{
    url = 'http://localhost:8089/api/Institute/GetInstituteById/'; 

    constructor(private httpClient: HttpClient){
        
    }

    getInstituteById (instituteId: number): Observable<Institute> {
        const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };
        return this.httpClient.get<Institute>(this.url + instituteId, httpOptions);
    }
}