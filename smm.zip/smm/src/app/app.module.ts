import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';

import { SidenavComponant } from './sidenav/sidenav.component';
import { HeaderComponant } from './header/header.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { InstituteComponent } from './institute/institute.component';
import { CourseComponent } from './course/course.component';

import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatListModule } from '@angular/material/list';

import { InstituteService } from './services/institute.service';

@NgModule({
  declarations: [
    AppComponent,
    SidenavComponant,
    HeaderComponant,
    DashboardComponent,
    HomeComponent,
    InstituteComponent,
    CourseComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
     //Matrial imports
     MatSidenavModule,
     MatToolbarModule,
     MatMenuModule,
     MatIconModule,
     MatDividerModule,
     MatListModule,
     HttpClientModule
  ],
  providers: [ 
    HttpClientModule, 
    InstituteService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
