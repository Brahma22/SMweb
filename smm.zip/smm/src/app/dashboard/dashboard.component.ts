import { Component, OnInit } from '@angular/core';
import { InstituteService } from '../services/institute.service';
import { Institute } from '../models/institute';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  institute: any;

  constructor(private instituteService: InstituteService) { 
  }

  ngOnInit(): void {
    this.getInstituteById(1);
  }

  getInstituteById(id: number): void{
    this.instituteService.getInstituteById(id).subscribe(data => {
      console.log(data);
      this.institute = data;
    }, error => {
      console.log(error);
    });
  }

}